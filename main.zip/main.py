from pydoc import TextDoc
from tkinter import *

tk = Tk()

tk.geometry('500x500')


def add():

    if str.get() != '':
        list.insert(0, str.get())
        ent.delete(0, END)
        

def clear():
    select = list.curselection()

    list.delete(select)

# frame start

fr = Frame(tk)
fr.pack(side=LEFT, padx=20)

fr1 = Frame(tk)
fr1.pack(side=RIGHT, padx=20)
# frame end

#fr start
str = StringVar()
ent = Entry(fr, textvariable=str)
ent.pack()
btn = Button(fr,text='SEND TODOLIST:)',command=add)
btn.pack(pady=10)
# fr end

# fr1 start
list = Listbox(fr1,width=20,height=25)
btn1 = Button(fr1, command=clear, text='CLEAR')
list.pack()
btn1.pack(pady=10)
tk.mainloop()